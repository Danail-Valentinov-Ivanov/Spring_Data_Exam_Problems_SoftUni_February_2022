package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.Forecast;
import softuni.exam.models.entity.enums.DaysOfWeek;

import java.util.Optional;

// TODO:
@Repository
public interface ForecastRepository extends JpaRepository<Forecast, Long> {

    @Query("select f from Forecast f where f.daysOfWeek = :daysOfWeek")
    Optional<Forecast> findByDaysOfWeek(DaysOfWeek daysOfWeek);
}
