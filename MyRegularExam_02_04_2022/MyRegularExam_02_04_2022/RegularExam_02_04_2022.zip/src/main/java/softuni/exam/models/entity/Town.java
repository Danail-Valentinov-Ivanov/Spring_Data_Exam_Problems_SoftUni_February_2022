package softuni.exam.models.entity;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "towns")
public class Town {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

//    higher than or equal to 2
    @Column(name = "town_name", nullable = false, unique = true)
    private String townName;

//    (must be positive), 0 as a value is exclusive
    @Column(nullable = false)
    private int population;

    @OneToMany(targetEntity = Agent.class, mappedBy = "town")
    private Set<Agent> agents;

    @OneToMany(targetEntity = Apartment.class, mappedBy = "town")
    private Set<Apartment> apartments;

    public Town() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTownName() {
        return townName;
    }

    public void setTownName(String townName) {
        this.townName = townName;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public Set<Agent> getAgents() {
        return agents;
    }

    public void setAgents(Set<Agent> agents) {
        this.agents = agents;
    }

    public Set<Apartment> getApartments() {
        return apartments;
    }

    public void setApartments(Set<Apartment> apartments) {
        this.apartments = apartments;
    }

    @Override
    public String toString() {
        return townName + " - " + population;
    }
}
